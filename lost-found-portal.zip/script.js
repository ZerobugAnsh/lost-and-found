document.getElementById("lostForm").addEventListener("submit", function(e){
    e.preventDefault();
    alert("Lost item reported successfully!");
});

document.getElementById("foundForm").addEventListener("submit", function(e){
    e.preventDefault();
    alert("Found item reported successfully!");
});

let sampleItems = [
    { type: "Lost", item: "ID Card", location: "Canteen", date: "2025-01-05" },
    { type: "Found", item: "Backpack", location: "PIET Lawn", date: "2025-01-06" }
];

let container = document.getElementById("listContainer");

sampleItems.forEach(i => {
    let box = document.createElement("div");
    box.className = "item-box";
    box.innerHTML = `
        <h3>${i.type} Item: ${i.item}</h3>
        <p><strong>Location:</strong> ${i.location}</p>
        <p><strong>Date:</strong> ${i.date}</p>
    `;
    container.appendChild(box);
});
